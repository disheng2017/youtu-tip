import evaluate as hf_evaluate
import re

try:
    pass_at_k = hf_evaluate.load("lm_eval/tasks/cruxeval/code_eval.py")

    # run simple test to check code execution is enabled before model generation
    test_cases = ["assert add(2, 3)==5"]
    candidates = [["def add(a,b): return a*b"]]
    results = pass_at_k.compute(references=test_cases, predictions=candidates, k=[1])
except Exception as e:
    raise e


def pass_at_1(predictions, references):
    # extracted_predictions = []
    # for prediction in predictions:
    #     match = re.search(r'\[ANSWER\]\s*\n(.*?)(?:\n\[|$)', prediction, flags=re.S)
    #     answer = match.group(1) if match else ""
    #     extracted_predictions.append(answer.strip())
    return pass_at_k.compute(
        references=predictions,
        predictions=[references],
        k=[1],
    )[0]["pass@1"]

