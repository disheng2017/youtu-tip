#!/bin/bash

# python utils.py --overwrite --output-dir native_cot --mode native-cot
