import evaluate as hf_evaluate


try:
    compute_ = hf_evaluate.load("lm_eval/tasks/humaneval/code_eval.py")
    test_cases = ["assert add(2, 3)==5"]
    candidates = [["def add(a,b): return a*b"]]
    results = compute_.compute(references=test_cases, predictions=candidates, k=[1])
except Exception as e:
    raise e


def pass_at_k(references, predictions, k):
    references = ["".join(references[0])]
    global compute_
    assert k is not None
    if isinstance(k, int):
        k = [k]
    res = compute_.compute(
        references=references,
        predictions=predictions,
        k=k,
    )
    return res[0]


def build_predictions(resps, docs):
    return [[doc["prompt"] + r for r in resp] for resp, doc in zip(resps, docs)]


def build_predictions_instruct(resps, docs):
    return [
        [
            doc["prompt"] + (r if r.rfind("```") == -1 else r[: r.rfind("```")])
            for r in resp
        ]
        for resp, doc in zip(resps, docs)
    ]
