from fuzzywuzzy import fuzz
from codebleu import calc_codebleu

def exact_match_score(references, predictions):
    """
    This function computes the average exact match score between the predicted codes and the ground truth codes. 
    It returns a float value between 0 and 1 indicating the degree of exact match between the predicted codes 
    and the ground truth codes, where a value of 1 means all the predicted codes exactly match their corresponding 
    ground truth codes and a value of 0 means none of the predicted codes exactly match their corresponding 
    ground truth codes.
    
    Args:
    predictions: list, predicted codes
    references: list, ground truth codes
    
    Returns:
    Float, the average exact match score between the predicted codes and the ground truth codes.
    """
    if len(predictions) != len(references):
        raise ValueError("The length of the predicted codes and the ground truth codes should be equal.")

    exact_match = 0
    for pred, gt in zip(predictions, references):
        if pred.split() == gt.split():
            exact_match += 1
    
    return round(exact_match / len(predictions), 5)

def edit_similarity_score(references, predictions):
    """
    This function computes the average edit similarity score between the predicted codes and the ground truth codes. 
    It returns a float value between 0 and 1 indicating the degree of similarity between the predicted codes 
    and the ground truth codes, where a value of 1 means all the predicted codes are identical to their corresponding 
    ground truth codes and a value of 0 means none of the predicted codes are similar to their corresponding 
    ground truth codes.
    
    Args:
    predictions: list, predicted codes
    references: list, ground truth codes
    
    Returns:
    Float, the average edit similarity score between the predicted codes and the ground truth codes.
    """
    if len(predictions) != len(references):
        raise ValueError("The length of the predicted codes and the ground truth codes should be equal.")
    
    edit_sim = 0.0
    for pred, gt in zip(predictions, references):
        edit_sim += fuzz.ratio(pred, gt)
    
    return round(edit_sim / len(predictions), 5)

def codebleu_score(references, predictions):
    
    """
    This function computes the average codebleu score between the predicted codes and the ground truth codes. 
    It returns a float value between 0 and 1 indicating the degree of similarity between the predicted codes 
    and the ground truth codes, where a value of 1 means all the predicted codes are identical to their corresponding 
    ground truth codes and a value of 0 means none of the predicted codes are similar to their corresponding 
    ground truth codes.
    
    Args:
    predictions: list, predicted codes
    references: list, ground truth codes
    language: str, the programming language of the codes
    weight: list, the weights for each n-gram
    
    Returns:
    Float, the average codebleu score between the predicted codes and the ground truth codes.
    """
    language = "python"
    weight = [0.25, 0.25, 0.25, 0.25]

    if len(predictions) != len(references):
        raise ValueError("The length of the predicted codes and the ground truth codes should be equal.")
    
    # remove \r for both pred and gt
    predictions = [pred.replace("\r", "") for pred in predictions]
    references = [gt.replace("\r", "") for gt in references]
    
    res_list = calc_codebleu(
        references,
        predictions,
        language,
        weight,
        tokenizer=None
    )

    return res_list['codebleu']

